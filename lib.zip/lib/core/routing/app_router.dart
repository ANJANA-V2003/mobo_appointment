import 'package:go_router/go_router.dart';
import 'package:mobo_appointment_project/core/routing/app_routes.dart';
import 'package:mobo_appointment_project/features/dashboard/dashboard_screen.dart';
import 'package:mobo_appointment_project/features/get_started/get_started_screen.dart';
import 'package:mobo_appointment_project/features/login/screens/login_screen_credentials_page.dart';
import 'package:mobo_appointment_project/features/login/screens/login_screen_server_page.dart';
import 'package:mobo_appointment_project/features/splash/splash_screen.dart';

final GoRouter appRouter = GoRouter(
  initialLocation: '/splash',
  routes: [
    GoRoute(
      path: '/splash',
      name: AppRoutes.splash,
      builder: (context, state) => SplashScreen(),
    ),
    GoRoute(
      path: '/get-started',
      name: AppRoutes.getStarted,
      builder: (context, state) => GetStartedScreen(),
    ),
    GoRoute(
      path: '/server-login',
      name: AppRoutes.serverLogin,
      builder: (context, state) => LoginScreenServerPage(),
    ),
    GoRoute(
      path: '/credential-login',
      name: AppRoutes.credentialLogin,
      builder: (context, state) {
        final extra = state.extra as Map<String, dynamic>;

        return LoginScreenCredentialsPage(
          serverUrl: extra['serverUrl'] as String,
          database: extra['database'] as String,
        );
      },
    ),

    GoRoute(
      path: '/dashboard',
      name: AppRoutes.dashboard,
      builder: (context, state) => DashboardScreen(),
    ),
  ],
);


