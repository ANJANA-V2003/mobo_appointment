class AppRoutes {
  static const String splash = "splash";
  static const String getStarted = "getStarted";
  static const String serverLogin = "serverLogin";
  static const String credentialLogin = "credentialLogin";
  static const String dashboard = "dashboard";
  static const String noModule = "noModule";
}