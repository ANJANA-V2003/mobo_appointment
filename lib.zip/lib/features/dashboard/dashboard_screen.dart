import 'package:flutter/material.dart';
import 'package:go_router/go_router.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:hugeicons/hugeicons.dart';
import 'package:hugeicons/styles/stroke_rounded.dart';
import 'package:provider/provider.dart';

import '../../core/routing/app_routes.dart';
import '../login/provider/auth_provider.dart';

class DashboardScreen extends StatefulWidget {
  const DashboardScreen({super.key});

  @override
  State<DashboardScreen> createState() => _DashboardScreenState();
}

class _DashboardScreenState extends State<DashboardScreen> {
  Future<void> _logout() async {
    await context.read<AuthProvider>().logout();

    if (!mounted) return;

    context.goNamed(AppRoutes.getStarted);
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        actions: [
          IconButton(
            onPressed: _logout,
            icon: HugeIcon(icon: HugeIconsStrokeRounded.logout01),
          ),
        ],
        title: Text(
          "Dashboard",
          style: TextStyle(
            fontFamily: GoogleFonts.manrope().fontFamily,
            fontWeight: FontWeight.w600,
          ),
        ),
      ),
      body: Center(
        child: Text(
          "DASHBOARD",
          style: TextStyle(
            fontFamily: GoogleFonts.manrope().fontFamily,
            fontSize: 30,
            fontWeight: FontWeight.w600,
          ),
        ),
      ),
    );
  }
}
